export type SkinType = 'apple' | 'mango' | 'grape' | 'kiwi' | 'orange' | 'strawberry';

export interface SkinConfig {
  id: SkinType;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    glow: string;
    accent: string;
  };
  emoji: string;
  description: string;
}

export const SKINS: Record<SkinType, SkinConfig> = {
  apple: {
    id: 'apple',
    name: 'Glossy Apple',
    colors: {
      primary: '#ef4444',
      secondary: '#dc2626',
      glow: 'rgba(239, 68, 68, 0.4)',
      accent: '#22c55e', // Green leaf
    },
    emoji: '🍎',
    description: 'Crisp, shiny red apple skin with organic leaf stems.',
  },
  mango: {
    id: 'mango',
    name: 'Sweet Mango',
    colors: {
      primary: '#f97316',
      secondary: '#eab308',
      glow: 'rgba(249, 115, 22, 0.4)',
      accent: '#22c55e',
    },
    emoji: '🥭',
    description: 'Golden yellow-orange gradient shade of fresh tropical mango.',
  },
  grape: {
    id: 'grape',
    name: 'Glitter Grape',
    colors: {
      primary: '#a855f7',
      secondary: '#7c3aed',
      glow: 'rgba(168, 85, 247, 0.4)',
      accent: '#4ade80',
    },
    emoji: '🍇',
    description: 'Vibrant violet cluster grapes skin with high gloss reflections.',
  },
  kiwi: {
    id: 'kiwi',
    name: 'Zesty Kiwi',
    colors: {
      primary: '#84cc16',
      secondary: '#65a30d',
      glow: 'rgba(132, 204, 22, 0.4)',
      accent: '#78350f', // Fuzzy brown skin outline
    },
    emoji: '🥝',
    description: 'Rich brown outer boundary enclosing a beautiful sliced kiwi center.',
  },
  orange: {
    id: 'orange',
    name: 'Juicy Orange',
    colors: {
      primary: '#f97316',
      secondary: '#ea580c',
      glow: 'rgba(249, 115, 22, 0.4)',
      accent: '#fde047',
    },
    emoji: '🍊',
    description: 'Sunkist citrus burst pattern with wedge structures.',
  },
  strawberry: {
    id: 'strawberry',
    name: 'Royal Berry',
    colors: {
      primary: '#ec4899',
      secondary: '#db2777',
      glow: 'rgba(236, 72, 153, 0.4)',
      accent: '#22c55e',
    },
    emoji: '🍓',
    description: 'Deep magenta pink seeds texture with cute royal vibes.',
  },
};

export interface Position {
  x: number;
  y: number;
}

export interface SnakeSegment {
  x: number;
  y: number;
  angle: number;
  scale: number;
}

export interface PowerUp {
  type: 'magnet' | 'shield' | 'boost';
  duration: number; // remaining ticks/ms
  active: boolean;
}

export interface Snake {
  id: string;
  name: string;
  isBot: boolean;
  skin: SkinType;
  segments: SnakeSegment[];
  speed: number;
  targetAngle: number;
  currentAngle: number;
  score: number;
  isBoosting: boolean;
  isDead: boolean;
  rank: number; // calculated dynamically
  powerUps: {
    magnet: number; // remaining frames
    shield: number; // remaining frames
    boost: number; // remaining frames
  };
  dashGauge: number; // boost resource
}

export interface Fruit {
  id: string;
  x: number;
  y: number;
  type: 'apple' | 'grape' | 'orange' | 'strawberry' | 'banana' | 'pineapple' | 'melon' | 'cherry' | 'magnet' | 'shield' | 'lightning';
  size: 'small' | 'medium' | 'large';
  value: number;
  glowColor: string;
  pulseOffset: number;
  scale: number;
  headingX?: number; // magnetic pull vectors
  headingY?: number;
}

export interface Obstacle {
  id: string;
  x: number;
  y: number;
  radius: number;
  type: 'rock' | 'magma' | 'crystal';
  color: string;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
  maxLife: number;
}

export interface ScorePopup {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  scale: number;
  life: number;
}
