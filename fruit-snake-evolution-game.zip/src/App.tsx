import React, { useState, useEffect } from 'react';
import StartScreen from './components/StartScreen';
import GameCanvas from './components/GameCanvas';
import { SkinType } from './types';
import { Trophy, RefreshCw, XCircle, Award, Volume2, VolumeX, Sparkles, AlertCircle, Trash2 } from 'lucide-react';

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [playerName, setPlayerName] = useState('FruitSlitherer');
  const [playerSkin, setPlayerSkin] = useState<SkinType>('apple');
  const [currentScore, setCurrentScore] = useState(0);

  // Stats stored in localStorage across browser sessions
  const [savedHighScore, setSavedHighScore] = useState(0);
  const [totalFruitsEaten, setTotalFruitsEaten] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Retrieve previous records from store
  useEffect(() => {
    const rawHigh = localStorage.getItem('snake_high_score');
    if (rawHigh) {
      setSavedHighScore(parseInt(rawHigh, 10));
    }

    const rawTotal = localStorage.getItem('snake_fruits_eaten_total');
    if (rawTotal) {
      setTotalFruitsEaten(parseInt(rawTotal, 10));
    }

    const savedSound = localStorage.getItem('snake_sound_enabled');
    if (savedSound !== null) {
      setSoundEnabled(savedSound === 'true');
    }
  }, []);

  const handleStartGame = (name: string, skin: SkinType) => {
    setPlayerName(name);
    setPlayerSkin(skin);
    setIsPlaying(true);
    setIsGameOver(false);
  };

  const handleFruitEaten = () => {
    const nextTotal = totalFruitsEaten + 1;
    setTotalFruitsEaten(nextTotal);
    localStorage.setItem('snake_fruits_eaten_total', String(nextTotal));
  };

  const handleGameOver = (finalScore: number) => {
    setCurrentScore(finalScore);
    setIsGameOver(true);

    // Save score metrics if larger
    if (finalScore > savedHighScore) {
      setSavedHighScore(finalScore);
      localStorage.setItem('snake_high_score', String(finalScore));
    }
  };

  const handleRestart = () => {
    setIsGameOver(false);
    setIsPlaying(false); // return to setup menu to customize skins/name easily
  };

  const handlePlayAgainInstant = () => {
    setIsGameOver(false);
    setIsPlaying(true);
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    localStorage.setItem('snake_sound_enabled', String(next));
  };

  const clearRecords = () => {
    if (confirm('Are you sure you want to reset all game statistics (high score, eaten fruits)?')) {
      localStorage.removeItem('snake_high_score');
      localStorage.removeItem('snake_fruits_eaten_total');
      setSavedHighScore(0);
      setTotalFruitsEaten(0);
    }
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#07090e] font-sans select-none">
      
      {/* 1. START MENU SETUP WINDOW */}
      {!isPlaying && !isGameOver && (
        <StartScreen
          onStartGame={handleStartGame}
          savedHighScore={savedHighScore}
          totalFruitsEaten={totalFruitsEaten}
        />
      )}

      {/* 2. LIVE GAME CANVAS PLAYGROUND */}
      {isPlaying && !isGameOver && (
        <GameCanvas
          playerName={playerName}
          playerSkin={playerSkin}
          onGameOver={handleGameOver}
          soundEnabled={soundEnabled}
          onFruitEaten={handleFruitEaten}
        />
      )}

      {/* 3. GAMEOVER OVERLAY PANEL */}
      {isGameOver && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center p-4 bg-[#07090e]/95 backdrop-blur-md select-none text-white animate-fade-in">
          
          <div className="absolute inset-0 opacity-15 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#3a4a6e 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

          {/* Core Scorecard Frame */}
          <div className="w-full max-w-md bg-white/5 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl shadow-orange-500/5 text-center relative max-h-[90vh] overflow-y-auto">
            
            {/* Crown ambient shine background icon */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-[#07090e] border border-white/10 rounded-2xl flex items-center justify-center shadow-lg transform rotate-45 select-none shrink-0">
              <div className="transform -rotate-45 flex items-center justify-center">
                <XCircle className="w-10 h-10 text-red-500" />
              </div>
            </div>

            <div className="mt-6 mb-4">
              <h2 className="text-3xl font-black uppercase text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-400 tracking-wider">
                SNAKE DIGESTED
              </h2>
              <p className="text-stone-300 text-xs mt-1 font-semibold uppercase tracking-widest px-4 py-1 bg-[#07090e] border border-white/5 rounded-full inline-block">
                Arena Match Concluded
              </p>
            </div>

            {/* Encouraging caption titles depending on outcome scores */}
            <div className="text-stone-200 text-xs italic px-3 py-2 bg-white/5 backdrop-blur-md rounded-xl border border-white/10 mb-6 font-medium">
              {currentScore >= savedHighScore && savedHighScore > 0 ? (
                <span className="text-yellow-400 flex items-center justify-center gap-1.5 font-bold">
                  <Sparkles className="w-4 h-4" /> NEW PERSONAL BEST RECORD!
                </span>
              ) : currentScore > 1000 ? (
                'Spectacular slithering! You conquered a massive bot chain.'
              ) : currentScore > 400 ? (
                'Healthy evolution! Munch down on larger fruits to expand quicker.'
              ) : (
                'Ouch! Avoid crashing into rocks and other bot segments.'
              )}
            </div>

            {/* Statistics Board */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-[#07090e] border border-white/10 p-4 rounded-2xl">
                <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">Your Scores</span>
                <div className="text-3xl font-black text-stone-100 mt-1 font-mono">{currentScore}</div>
              </div>
              <div className="bg-[#07090e] border border-white/10 p-4 rounded-2xl flex flex-col justify-center">
                <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider flex items-center justify-center gap-1">
                  <Trophy className="w-3.5 h-3.5 text-yellow-500" /> Peak Best
                </span>
                <div className="text-3xl font-black text-amber-400 mt-1 font-mono">
                  {Math.max(currentScore, savedHighScore)}
                </div>
              </div>
            </div>

            {/* Navigation buttons */}
            <div className="flex flex-col gap-3">
              <button
                onClick={handlePlayAgainInstant}
                className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-400 hover:to-red-400 font-extrabold text-sm py-4 rounded-xl shadow-lg transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-4 h-4 animate-spin-slow" />
                <span>QUICK REPLAY</span>
              </button>

              <button
                onClick={handleRestart}
                className="w-full bg-white/10 hover:bg-white/15 font-bold text-xs text-stone-200 py-3 rounded-xl border border-white/15 transition active:scale-98 cursor-pointer"
              >
                RETURN TO SETUP SCREEN
              </button>
            </div>

            {/* Secondary footer items stats reset option */}
            <div className="mt-8 flex justify-between items-center text-[10px] text-stone-400 border-t border-white/10 pt-4 px-1.5 font-semibold">
              <button
                onClick={clearRecords}
                className="flex items-center gap-1.5 hover:text-red-400 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>RESET SAVED STATS</span>
              </button>

              <button
                onClick={toggleSound}
                className="flex items-center gap-1 px-1 py-0.5 hover:text-white transition"
              >
                {soundEnabled ? (
                  <Volume2 className="w-3.5 h-3.5 text-orange-400" />
                ) : (
                  <VolumeX className="w-3.5 h-3.5 text-stone-500" />
                )}
                <span>SOUNDS</span>
              </button>
            </div>

          </div>
        </div>
      )}
    </main>
  );
}
