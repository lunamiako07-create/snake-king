import React, { useState, useEffect } from 'react';
import { SKINS, SkinType } from '../types';
import { Play, Sparkles, Trophy, RotateCcw, Shield, Zap, CircleDot, Info, Volume2, VolumeX } from 'lucide-react';

interface StartScreenProps {
  onStartGame: (name: string, skin: SkinType) => void;
  savedHighScore: number;
  totalFruitsEaten: number;
}

const RANDOM_NAMES = [
  'BerryKing', 'Mangoo', 'AppleX', 'KiwiMaster', 'LemonBoy',
  'MelonMage', 'PeachPrince', 'GrapeGuardian', 'CherryChewer',
  'CoconutCzar', 'PlumPlodder', 'CitrusSlasher', 'BananaBoss'
];

export default function StartScreen({ onStartGame, savedHighScore, totalFruitsEaten }: StartScreenProps) {
  const [name, setName] = useState('');
  const [selectedSkin, setSelectedSkin] = useState<SkinType>('apple');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Generate random name initially
  useEffect(() => {
    generateRandomName();
    
    // Get sound prefix
    const savedSound = localStorage.getItem('snake_sound_enabled');
    if (savedSound !== null) {
      setSoundEnabled(savedSound === 'true');
    }
  }, []);

  const generateRandomName = () => {
    const random = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];
    const digit = Math.floor(Math.random() * 900) + 100;
    setName(`${random}${digit}`);
  };

  const handleStart = () => {
    const finalName = name.trim() || 'FruitSlitherer';
    onStartGame(finalName, selectedSkin);
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    localStorage.setItem('snake_sound_enabled', String(next));
  };

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-between p-4 md:p-8 overflow-y-auto bg-[#07090e] select-none text-white font-sans">
      {/* Grid Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#3a4a6e 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,rgba(58,74,110,0.15)_0%,transparent_70%)] pointer-events-none" />

      {/* Header Panel */}
      <div className="w-full max-w-lg mt-4 text-center z-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 mb-3 rounded-full bg-white/10 border border-white/20 text-orange-400 text-xs font-semibold uppercase tracking-wider animate-pulse">
          <Sparkles className="w-3.5 h-3.5" />
          Fruit Evolution Engine v1.0
        </div>
        <h1 className="text-4xl md:text-5xl font-black tracking-tight uppercase text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-pink-500 to-purple-500 drop-shadow-[0_4px_12px_rgba(249,115,22,0.3)]">
          FRUIT SNAKE
        </h1>
        <p className="text-stone-400 text-xs md:text-sm tracking-wide mt-1 font-medium">
          Evolution Arena • Slither, Munch & Rule the Orchard
        </p>
      </div>

      {/* Game Settings Grid & Skin Selector */}
      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-6 my-auto py-4 z-10">
        {/* Left column - Nickname & Stats */}
        <div className="lg:col-span-5 flex flex-col gap-5 justify-center">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5 rounded-3xl shadow-2xl">
            <label className="block text-xs font-bold uppercase text-stone-400 tracking-wider mb-2">
              Select Nickname
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                maxLength={14}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter Nickname..."
                className="flex-1 bg-stone-950/60 border border-white/10 hover:border-white/20 focus:border-orange-500 rounded-xl px-4 py-3 text-sm font-semibold outline-none transition text-white"
              />
              <button
                onClick={generateRandomName}
                type="button"
                className="px-4 py-3 bg-white/10 hover:bg-white/15 active:bg-white/5 text-xs font-bold uppercase transition rounded-xl border border-white/20 hover:border-orange-500 text-orange-400 cursor-pointer"
              >
                Roll
              </button>
            </div>
          </div>

          {/* Stats Bento Box */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl shadow-2xl flex flex-col items-center justify-center text-center">
              <Trophy className="w-6 h-6 text-yellow-400 mb-1 filter drop-shadow-[0_2px_4px_rgba(234,179,8,0.3)]" />
              <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wide">High Length</span>
              <span className="text-xl font-extrabold text-white mt-0.5">
                {savedHighScore > 0 ? savedHighScore : '---'}
              </span>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl shadow-2xl flex flex-col items-center justify-center text-center">
              <CircleDot className="w-6 h-6 text-pink-400 mb-1 filter drop-shadow-[0_2px_4px_rgba(236,72,153,0.3)]" />
              <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wide">Eaten Fruits</span>
              <span className="text-xl font-extrabold text-white mt-0.5">
                {totalFruitsEaten > 0 ? totalFruitsEaten : '---'}
              </span>
            </div>
          </div>

          {/* Interactive Controls Guide */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-4 rounded-2xl shadow-2xl text-xs text-stone-400 space-y-2.5">
            <div className="font-bold uppercase text-stone-300 flex items-center gap-1.5 border-b border-white/10 pb-1.5 mb-1.5">
              <Info className="w-4 h-4 text-orange-400" /> Game Controller Guide
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-stone-300">Steering / Move:</span>
              <span className="text-stone-200 bg-black/40 px-2 py-0.5 rounded border border-white/10">Touch & Drag or Mouse Hover</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-stone-300">Lightning Boost:</span>
              <span className="text-stone-200 bg-black/40 px-2 py-0.5 rounded border border-white/10">Tap Boost Icon or Left Mouse Click</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-stone-300">Evolution Path:</span>
              <span className="text-stone-200 flex items-center gap-1">Collect Magnet <Zap className="w-3 h-3 text-blue-400 inline" />, Shield <Shield className="w-3 h-3 text-emerald-400 inline" /></span>
            </div>
          </div>
        </div>

        {/* Right column - Skins Grid & Live Preview */}
        <div className="lg:col-span-7 bg-white/5 backdrop-blur-2xl border border-white/10 p-5 rounded-3xl flex flex-col justify-between shadow-2xl">
          <div>
            <h2 className="text-xs font-bold uppercase text-stone-300 tracking-wider mb-4 flex items-center gap-2">
              <span>Select Fruit Skin Evolution</span>
              <span className="px-2 py-0.5 rounded-md bg-white/10 text-[10px] text-orange-400 border border-white/10 font-extrabold">
                {Object.keys(SKINS).length} Available
              </span>
            </h2>

            {/* Grid of skin elements */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
              {Object.values(SKINS).map((cfg) => {
                const isSelected = selectedSkin === cfg.id;
                return (
                  <button
                    key={cfg.id}
                    onClick={() => setSelectedSkin(cfg.id)}
                    className={`relative p-3 rounded-2xl border text-left transition flex items-center gap-2.5 overflow-hidden cursor-pointer ${
                      isSelected
                        ? 'bg-white/15 border-orange-500 shadow-lg shadow-orange-500/10'
                        : 'bg-white/5 border-white/10 hover:border-white/25'
                    }`}
                  >
                    {/* Background glow of active selection */}
                    {isSelected && (
                      <div
                        className="absolute inset-0 opacity-10 pointer-events-none"
                        style={{ backgroundColor: cfg.colors.primary }}
                      />
                    )}
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-xl transition-transform duration-300 shrink-0 select-none"
                      style={{
                        backgroundColor: `${cfg.colors.primary}15`,
                        borderColor: isSelected ? cfg.colors.primary : `${cfg.colors.primary}40`,
                        borderWidth: '1px',
                        boxShadow: isSelected ? `0 0 12px ${cfg.colors.glow}` : 'none'
                      }}
                    >
                      {cfg.emoji}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate text-stone-200">{cfg.name}</div>
                      <div className="text-[9px] text-stone-400 truncate mt-0.5 uppercase tracking-tight">
                        {cfg.id} type
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Skin Preview visualization block */}
          <div className="relative h-28 bg-[#07090e] border border-white/10 rounded-2xl flex items-center justify-center overflow-hidden p-4 mb-2">
            <div className="absolute inset-x-0 bottom-0 bg-white/5 border-t border-white/10 text-[9px] text-center font-semibold text-stone-400 tracking-wider py-1 select-none">
              LIVE PREVIEW • OSCILLATORY INTERPOLATION
            </div>

            {/* Glowing circle ambient backdrop */}
            <div
              className="absolute w-24 h-24 rounded-full blur-2xl opacity-20 pointer-events-none animate-pulse-slow"
              style={{ backgroundColor: SKINS[selectedSkin].colors.primary }}
            />

            {/* Decorative oscillating preview snake using HTML elements */}
            <div className="relative flex items-center gap-1.5">
              {/* Tails */}
              <div
                className="w-4 h-4 rounded-full opacity-45 border border-white/10 animate-bounce"
                style={{
                  backgroundColor: SKINS[selectedSkin].colors.secondary,
                  animationDelay: '0.3s',
                }}
              />
              <div
                className="w-5.5 h-5.5 rounded-full opacity-65 border border-white/10 animate-bounce"
                style={{
                  backgroundColor: SKINS[selectedSkin].colors.primary,
                  animationDelay: '0.2s',
                }}
              />
              <div
                className="w-7 h-7 rounded-full opacity-80 border border-white/10 animate-bounce"
                style={{
                  backgroundColor: SKINS[selectedSkin].colors.secondary,
                  animationDelay: '0.1s',
                }}
              />
              {/* Body */}
              <div
                className="w-8.5 h-8.5 rounded-full border border-white/15 shadow-md flex items-center justify-center animate-bounce relative"
                style={{
                  backgroundColor: SKINS[selectedSkin].colors.primary,
                  boxShadow: `0 0 10px ${SKINS[selectedSkin].colors.glow}`,
                  animationDelay: '0s',
                }}
              >
                {/* Seed nodes or fruit patterns */}
                <div className="absolute top-1 right-2 w-1.5 h-1.5 rounded-full bg-white/40" />
              </div>
              {/* Head with Animated Eyes */}
              <div
                className="w-10 h-10 rounded-full border-2 shadow-lg flex items-center justify-center relative animate-pulse"
                style={{
                  backgroundColor: SKINS[selectedSkin].colors.primary,
                  borderColor: SKINS[selectedSkin].colors.accent,
                }}
              >
                {/* Shiny white bubble glint */}
                <div className="absolute top-1 left-2 w-2.5 h-2 w-2.5 rounded-full bg-white/50" />
                {/* STEM leaf crown */}
                <div
                  className="absolute -top-1.5 right-3.5 w-2 h-3.5 rounded-full origin-bottom rotate-12"
                  style={{ backgroundColor: SKINS[selectedSkin].colors.accent }}
                />
                
                {/* Eyes */}
                <div className="flex gap-1.5 mt-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-stone-950 flex items-center justify-center">
                    <div className="w-1 h-1 rounded-full bg-white" />
                  </div>
                  <div className="w-2.5 h-2.5 rounded-full bg-stone-950 flex items-center justify-center">
                    <div className="w-1 h-1 rounded-full bg-white" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Play Controls and Sound Button */}
      <div className="w-full max-w-sm flex flex-col gap-3 mb-4 mt-2 z-10">
        <button
          onClick={handleStart}
          aria-label="Start Evolution Arena Game"
          className="group relative w-full overflow-hidden bg-gradient-to-r from-orange-500 via-pink-500 to-red-500 hover:from-orange-400 hover:via-pink-400 hover:to-red-400 text-white font-extrabold text-lg py-4 rounded-2xl shadow-[0_4px_25px_rgba(249,115,22,0.4)] hover:shadow-[0_4px_30px_rgba(249,115,22,0.6)] border border-white/20 active:scale-98 transition-all flex items-center justify-center gap-3 cursor-pointer"
        >
          {/* Pulsating backdrop */}
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition duration-300" />
          <Play className="w-5 h-5 fill-white group-hover:scale-110 transition duration-300" />
          <span>ENTER ARENA</span>
        </button>

        <div className="flex justify-between items-center px-2 text-stone-500 text-[10px] font-semibold">
          <span>COOKIE LOCAL STORAGE ACTIVE</span>
          <button
            onClick={toggleSound}
            className="flex items-center gap-1.5 text-stone-400 hover:text-white transition"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-orange-400" />
                <span>SOUND EFFECTS: ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-stone-500" />
                <span>SOUND EFFECTS: OFF</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
