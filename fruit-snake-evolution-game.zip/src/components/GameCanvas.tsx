import React, { useEffect, useRef, useState } from 'react';
import { Snake, Fruit, Obstacle, Particle, ScorePopup, SkinType, SKINS, Position } from '../types';
import { Shield, Zap, CircleDot, Award, Trophy, Compass, ArrowRight, Heart } from 'lucide-react';

interface GameCanvasProps {
  playerName: string;
  playerSkin: SkinType;
  onGameOver: (score: number) => void;
  soundEnabled: boolean;
  onFruitEaten: () => void;
}

// World Boundaries
const WORLD_SIZE = 5000;
const BOT_COUNT = 15;
const FRUIT_COUNT = 350;
const OBSTACLE_COUNT = 25;

// Synthesize sound effects procedurally using Web Audio API to prevent CORS issues
class SoundEffectsManager {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  constructor(enabled: boolean) {
    this.enabled = enabled;
  }

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
  }

  playEat() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(150, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, this.ctx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.12);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.12);
    } catch (e) {
      // Ignored
    }
  }

  playBoost() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.type = 'sine';
      osc.frequency.setValueAtTime(300, this.ctx.currentTime);
      osc.frequency.setValueAtTime(380, this.ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.1);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.1);
    } catch (e) {
      // Ignored
    }
  }

  playPowerup() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, this.ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(600, this.ctx.currentTime + 0.2);
      osc.frequency.linearRampToValueAtTime(1200, this.ctx.currentTime + 0.4);

      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.45);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.45);
    } catch (e) {
      // Ignored
    }
  }

  playDeath() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    try {
      // Procedural explosion noise
      const bufferSize = this.ctx.sampleRate * 0.4; // 0.4 seconds
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noiseNode = this.ctx.createBufferSource();
      noiseNode.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, this.ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(100, this.ctx.currentTime + 0.35);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.4);

      noiseNode.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noiseNode.start();
      noiseNode.stop(this.ctx.currentTime + 0.4);
    } catch (e) {
      // Ignored
    }
  }
}

export default function GameCanvas({
  playerName,
  playerSkin,
  onGameOver,
  soundEnabled,
  onFruitEaten,
}: GameCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Sound manager ref
  const soundRef = useRef<SoundEffectsManager | null>(null);

  // Offscreen canvas pattern for rocky volcanic ground
  const patternCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // States for HUD overlay updates (React)
  const [playerScore, setPlayerScore] = useState(0);
  const [playerRank, setPlayerRank] = useState(1);
  const [leaderboard, setLeaderboard] = useState<{ name: string; score: number; skin: SkinType; isPlayer: boolean }[]>([]);
  const [questCount, setQuestCount] = useState(0);
  const [questGoal] = useState(350); // eat total food
  const [activeMagnet, setActiveMagnet] = useState(0);
  const [activeShield, setActiveShield] = useState(0);
  const [fps, setFps] = useState(60);

   // Engine state refs to maintain precise 60 FPS requestAnimationFrame operations
  const stateRef = useRef<{
    gameTime: number;
    playerSnakeId: string;
    snakes: Snake[];
    fruits: Fruit[];
    obstacles: Obstacle[];
    particles: Particle[];
    popups: ScorePopup[];
    camera: Position;
    mousePos: Position;
    hasMovedMouse: boolean;
    shakeStrength: number;
    isBoostPressed: boolean;
    joystickStart: Position | null;
    joystickCurrent: Position | null;
    showJoystick: boolean;
  }>({
    gameTime: 0,
    playerSnakeId: 'player_' + Math.random().toString(36).substring(3, 9),
    snakes: [],
    fruits: [],
    obstacles: [],
    particles: [],
    popups: [],
    camera: { x: WORLD_SIZE / 2, y: WORLD_SIZE / 2 },
    mousePos: { x: 0, y: 0 },
    hasMovedMouse: false,
    shakeStrength: 0,
    isBoostPressed: false,
    joystickStart: null,
    joystickCurrent: null,
    showJoystick: false,
  });

  // Keep references updated
  useEffect(() => {
    if (!soundRef.current) {
      soundRef.current = new SoundEffectsManager(soundEnabled);
    } else {
      soundRef.current.enabled = soundEnabled;
    }
  }, [soundEnabled]);

  // Spawn and initialize world entity structures
  const initEngine = () => {
    const s = stateRef.current;
    s.snakes = [];
    s.fruits = [];
    s.obstacles = [];
    s.particles = [];
    s.popups = [];
    s.shakeStrength = 0;
    s.hasMovedMouse = false;
    s.joystickStart = null;
    s.joystickCurrent = null;
    s.showJoystick = false;

    // Create rock obstacles
    for (let i = 0; i < OBSTACLE_COUNT; i++) {
      const radius = 30 + Math.random() * 45;
      s.obstacles.push({
        id: `rock_${i}`,
        x: radius + Math.random() * (WORLD_SIZE - radius * 2),
        y: radius + Math.random() * (WORLD_SIZE - radius * 2),
        radius,
        type: Math.random() > 0.7 ? (Math.random() > 0.5 ? 'magma' : 'crystal') : 'rock',
        color: ['#44403c', '#57534e', '#292524'][Math.floor(Math.random() * 3)],
      });
    }

    // Place Player Snake in center coordinate safely
    const startX = WORLD_SIZE / 2;
    const startY = WORLD_SIZE / 2;
    const playerSegments = [];
    const snakeLength = 12;
    const initialAngle = Math.random() * Math.PI * 2;

    for (let j = 0; j < snakeLength; j++) {
      playerSegments.push({
        x: startX - Math.cos(initialAngle) * j * 16,
        y: startY - Math.sin(initialAngle) * j * 16,
        angle: initialAngle,
        scale: 1.0,
      });
    }

    s.snakes.push({
      id: s.playerSnakeId,
      name: playerName,
      isBot: false,
      skin: playerSkin,
      segments: playerSegments,
      speed: 4,
      targetAngle: initialAngle,
      currentAngle: initialAngle,
      score: 120, // initial structural scale
      isBoosting: false,
      isDead: false,
      rank: 1,
      powerUps: { magnet: 0, shield: 0, boost: 0 },
      dashGauge: 100,
    });

    // Populate computer Bots with different skin presets
    const botSkins: SkinType[] = ['apple', 'mango', 'grape', 'kiwi', 'orange', 'strawberry'];
    const botNames = [
      'BerryKing', 'Mangoo', 'AppleX', 'KiwiMaster', 'LemonBoy',
      'SweetCitrus', 'Grapevine', 'PlumCrush', 'MelonMagician',
      'CobraCherry', 'AnacondaOrange', 'SlayerSunkist', 'FuzzyKiwi',
      'BananaSplit', 'NectarQueen'
    ];

    for (let b = 0; b < BOT_COUNT; b++) {
      const randX = 300 + Math.random() * (WORLD_SIZE - 600);
      const randY = 300 + Math.random() * (WORLD_SIZE - 600);
      const botSegments = [];
      const botLen = 10 + Math.floor(Math.random() * 15);
      const botAngle = Math.random() * Math.PI * 2;

      for (let j = 0; j < botLen; j++) {
        botSegments.push({
          x: randX - Math.cos(botAngle) * j * 16,
          y: randY - Math.sin(botAngle) * j * 16,
          angle: botAngle,
          scale: 1.0,
        });
      }

      s.snakes.push({
        id: `bot_${b}_${Math.random()}`,
        name: botNames[b % botNames.length],
        isBot: true,
        skin: botSkins[b % botSkins.length],
        segments: botSegments,
        speed: 3 + Math.random() * 1.5,
        targetAngle: botAngle,
        currentAngle: botAngle,
        score: botLen * 10,
        isBoosting: false,
        isDead: false,
        rank: b + 2,
        powerUps: { magnet: 0, shield: 0, boost: 0 },
        dashGauge: 100,
      });
    }

    // Populate Fruits
    for (let f = 0; f < FRUIT_COUNT; f++) {
      spawnRandomFruit(false);
    }
  };

  // Helper function to spawn fruit dynamically
  const spawnRandomFruit = (nearDeath: boolean, fixedPos?: Position) => {
    const s = stateRef.current;
    let rx = 100 + Math.random() * (WORLD_SIZE - 200);
    let ry = 100 + Math.random() * (WORLD_SIZE - 200);

    if (fixedPos) {
      rx = fixedPos.x;
      ry = fixedPos.y;
    }

    const types: Fruit['type'][] = [
      'apple', 'grape', 'orange', 'strawberry', 'banana',
      'pineapple', 'melon', 'cherry', 'magnet', 'shield', 'lightning'
    ];
    // Heavily skew towards standard fruit eats, special powerups appear less often
    let type: Fruit['type'] = 'apple';
    const rand = Math.random();
    if (nearDeath) {
      const basicFruits: Fruit['type'][] = ['apple', 'grape', 'orange', 'strawberry', 'cherry'];
      type = basicFruits[Math.floor(Math.random() * basicFruits.length)];
    } else {
      if (rand < 0.4) type = 'apple';
      else if (rand < 0.55) type = 'grape';
      else if (rand < 0.7) type = 'orange';
      else if (rand < 0.8) type = 'strawberry';
      else if (rand < 0.88) type = 'cherry';
      else if (rand < 0.93) type = 'banana';
      else if (rand < 0.95) type = 'pineapple';
      else if (rand < 0.97) type = 'melon';
      else if (rand < 0.98) type = 'magnet';
      else if (rand < 0.99) type = 'shield';
      else type = 'lightning';
    }

    const sizes: Fruit['size'][] = ['small', 'medium', 'large'];
    const size = sizes[Math.floor(Math.random() * (nearDeath ? 2 : 3))];

    let value = 10;
    if (size === 'medium') value = 20;
    if (size === 'large') value = 40;

    // Powerups give higher score + temporary statuses
    if (type === 'magnet' || type === 'shield' || type === 'lightning') {
      value = 50;
    }

    s.fruits.push({
      id: `fruit_${Math.random()}`,
      x: rx,
      y: ry,
      type,
      size,
      value,
      glowColor: type === 'magnet' ? '#3b82f6' : type === 'shield' ? '#10b981' : type === 'lightning' ? '#f59e0b' : '#ec4899',
      pulseOffset: Math.random() * Math.PI * 2,
      scale: size === 'small' ? 0.7 : size === 'medium' ? 1.0 : 1.3,
    });
  };

  // Generate procedural tiled basalt rocky backdrop once to save CPU
  const generatePatternTexture = () => {
    const scale = 2; // high res texture pattern canvas
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 256 * scale;
    pCanvas.height = 256 * scale;
    const pCtx = pCanvas.getContext('2d');
    if (!pCtx) return;

    pCtx.save();
    pCtx.scale(scale, scale);

    // Dark grey slab base
    pCtx.fillStyle = '#0c0a09'; 
    pCtx.fillRect(0, 0, 256, 256);

    // Draw cracked lava-themed borders / dry rock tiles
    pCtx.strokeStyle = '#1c1917';
    pCtx.lineWidth = 1.5;

    // Custom polygonal rock plate lines
    const drawCracks = () => {
      pCtx.beginPath();
      // Draw random lines
      pCtx.moveTo(0, 40); pCtx.lineTo(60, 0);
      pCtx.moveTo(60, 0); pCtx.lineTo(140, 50);
      pCtx.moveTo(140, 50); pCtx.lineTo(256, 20);
      pCtx.moveTo(140, 50); pCtx.lineTo(120, 160);
      pCtx.moveTo(120, 160); pCtx.lineTo(0, 200);
      pCtx.moveTo(120, 160); pCtx.lineTo(210, 220);
      pCtx.moveTo(210, 220); pCtx.lineTo(256, 170);
      pCtx.moveTo(0, 110); pCtx.lineTo(70, 90);
      pCtx.moveTo(70, 90); pCtx.lineTo(120, 160);
      pCtx.moveTo(210, 220); pCtx.lineTo(200, 256);
      pCtx.stroke();
    };
    drawCracks();

    // Soft lava glow cracks underneath
    pCtx.strokeStyle = 'rgba(239, 68, 68, 0.15)'; // deep ambient fire blood
    pCtx.lineWidth = 3;
    drawCracks();

    pCtx.strokeStyle = 'rgba(249, 115, 22, 0.08)'; // orange accents
    pCtx.lineWidth = 1;
    drawCracks();

    // Speckled fine basalt pebbles
    for (let i = 0; i < 40; i++) {
      const px = Math.random() * 256;
      const py = Math.random() * 256;
      const sz = 0.5 + Math.random() * 1.5;
      pCtx.fillStyle = `rgba(87, 83, 78, ${0.1 + Math.random() * 0.15})`;
      pCtx.beginPath();
      pCtx.arc(px, py, sz, 0, Math.PI * 2);
      pCtx.fill();
    }

    // Glow craters
    for (let i = 0; i < 4; i++) {
      const cx = Math.random() * 256;
      const cy = Math.random() * 256;
      const r = 5 + Math.random() * 15;
      const radGlow = pCtx.createRadialGradient(cx, cy, 0, cx, cy, r);
      radGlow.addColorStop(0, 'rgba(239, 68, 68, 0.04)');
      radGlow.addColorStop(1, 'rgba(0,0,0,0)');
      pCtx.fillStyle = radGlow;
      pCtx.beginPath();
      pCtx.arc(cx, cy, r, 0, Math.PI * 2);
      pCtx.fill();
    }

    pCtx.restore();
    patternCanvasRef.current = pCanvas;
  };

  // Keyboard, Mouse, and Touch interactions
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Render basalt procedurally
    generatePatternTexture();

    // Initialize state
    initEngine();

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const s = stateRef.current;
      s.mousePos = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
      s.hasMovedMouse = true;
    };

    const handleMouseDown = (e: MouseEvent) => {
      const s = stateRef.current;
      if (e.button === 0) {
        s.isBoostPressed = true;
      }
      s.hasMovedMouse = true;
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        stateRef.current.isBoostPressed = false;
      }
    };

    // Keyboard controls
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        stateRef.current.isBoostPressed = true;
        stateRef.current.hasMovedMouse = true;
        e.preventDefault();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        stateRef.current.isBoostPressed = false;
        e.preventDefault();
      }
    };

    // Modern Responsive Touch Controls with Dynamic Virtual Thumb Joystick
    const handleTouchStart = (e: TouchEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.closest('button') || target.tagName === 'BUTTON')) {
        return; // ignore button clicks to avoid collision steering
      }

      if (e.touches.length > 0) {
        const rect = canvas.getBoundingClientRect();
        const touch = e.touches[0];
        const tx = touch.clientX - rect.left;
        const ty = touch.clientY - rect.top;

        // Skip if in bottom-right Boost button safety zone (130px radius)
        if (tx > rect.width - 130 && ty > rect.height - 130) {
          return;
        }

        const s = stateRef.current;
        s.joystickStart = { x: tx, y: ty };
        s.joystickCurrent = { x: tx, y: ty };
        s.showJoystick = true;
        s.hasMovedMouse = true;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      const s = stateRef.current;
      if (s.showJoystick && s.joystickStart && e.touches.length > 0) {
        const rect = canvas.getBoundingClientRect();
        // find the touch that matches or just take the first one
        const touch = e.touches[0];
        const tx = touch.clientX - rect.left;
        const ty = touch.clientY - rect.top;
        s.joystickCurrent = { x: tx, y: ty };

        const dx = s.joystickCurrent.x - s.joystickStart.x;
        const dy = s.joystickCurrent.y - s.joystickStart.y;
        const dist = Math.hypot(dx, dy);

        if (dist > 5) {
          const playerSnake = s.snakes.find((sn) => sn.id === s.playerSnakeId);
          if (playerSnake && !playerSnake.isDead) {
            playerSnake.targetAngle = Math.atan2(dy, dx);
          }
        }
      }
    };

    const handleTouchEnd = () => {
      const s = stateRef.current;
      s.showJoystick = false;
      s.joystickStart = null;
      s.joystickCurrent = null;
    };

    // Prevent scrolling elastic on mobile touch movements
    const preventScroll = (e: Event) => {
      e.preventDefault();
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('touchstart', handleTouchStart, { passive: true });
    canvas.addEventListener('touchmove', handleTouchMove, { passive: true });
    canvas.addEventListener('touchend', handleTouchEnd, { passive: true });
    canvas.addEventListener('touchcancel', handleTouchEnd, { passive: true });
    document.body.addEventListener('touchmove', preventScroll, { passive: false });

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mousedown', handleMouseDown);
      canvas.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEnd);
      canvas.removeEventListener('touchcancel', handleTouchEnd);
      document.body.removeEventListener('touchmove', preventScroll);
    };
  }, []);

  // Frame Loop (Renderer + Physics Integration)
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();
    let frameTicks = 0;
    let lastFpsUpdate = 0;
    let accumulator = 0;
    const dt = 1000 / 60; // 60Hz fixed step (~16.67ms)

    const gameLoop = (now: number) => {
      const s = stateRef.current;
      s.gameTime = now;

      let deltaTime = now - lastTime;
      if (deltaTime > 250) deltaTime = 250;
      lastTime = now;

      accumulator += deltaTime;

      while (accumulator >= dt) {
        updateLogic();
        accumulator -= dt;
      }

      // Handle raw FPS counting
      frameTicks++;
      if (now - lastFpsUpdate >= 1000) {
        setFps(frameTicks);
        frameTicks = 0;
        lastFpsUpdate = now;
      }

      // Draw graphics
      renderCanvas();

      animId = requestAnimationFrame(gameLoop);
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, []);

  // --- CORE GAME METRICS AND MOVEMENT UPDATE LOGIC ---
  const updateLogic = () => {
    const s = stateRef.current;
    if (s.snakes.length === 0) return;

    // Check if player is dead, if yes exit processing loop
    const playerSnake = s.snakes.find((sn) => sn.id === s.playerSnakeId);
    if (!playerSnake || playerSnake.isDead) {
      return;
    }

    // 1. UPDATE PLAYER INPUT STEERING
    if (s.hasMovedMouse) {
      const canvas = canvasRef.current;
      if (canvas) {
        if (s.showJoystick && s.joystickStart && s.joystickCurrent) {
          const dx = s.joystickCurrent.x - s.joystickStart.x;
          const dy = s.joystickCurrent.y - s.joystickStart.y;
          if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
            playerSnake.targetAngle = Math.atan2(dy, dx);
          }
        } else {
          // Classic Desktop Mouse steering: calculation relative to viewport screen center
          const centerX = canvas.width / 2;
          const centerY = canvas.height / 2;
          const dx = s.mousePos.x - centerX;
          const dy = s.mousePos.y - centerY;

          // Avoid jumping angle on dead-center hovered cursors
          if (Math.abs(dx) > 15 || Math.abs(dy) > 15) {
            playerSnake.targetAngle = Math.atan2(dy, dx);
          }
        }
      }
    }

    // 2. DETECT POWER-UPS COOLDOWNS & DASH ATTRIBUTES
    s.snakes.forEach((snake) => {
      // Decay active statuses
      if (snake.powerUps.magnet > 0) snake.powerUps.magnet--;
      if (snake.powerUps.shield > 0) snake.powerUps.shield--;
      if (snake.powerUps.boost > 0) snake.powerUps.boost--;

      // Render React states for the player specifically
      if (snake.id === s.playerSnakeId) {
        setActiveMagnet(snake.powerUps.magnet);
        setActiveShield(snake.powerUps.shield);
      }

      // Boosting physics: Needs enough dash gauges or score
      const wantsBoost = snake.isBot
        ? snake.isBoosting // Bot state
        : s.isBoostPressed; // Player action

      if (wantsBoost && snake.score > 80) {
        snake.speed = 7.0; // zoom factor
        snake.isBoosting = true;

        // Drain gauge and score progressively as trail residues
        if (Math.random() < 0.15) {
          snake.score = Math.max(80, snake.score - 5);
          // Spawn fruit debris left behind due to high speed friction!
          const tailSeg = snake.segments[snake.segments.length - 1];
          if (tailSeg) {
            spawnRandomFruit(true, { x: tailSeg.x + (Math.random() * 20 - 10), y: tailSeg.y + (Math.random() * 20 - 10) });
          }
          if (snake.id === s.playerSnakeId) {
            soundRef.current?.playBoost();
          }
        }
      } else {
        snake.speed = 3.5; // regular crawl speed
        snake.isBoosting = false;
      }

      // Regrow dash gauge slowly
      if (!snake.isBoosting && snake.dashGauge < 100) {
        snake.dashGauge = Math.min(100, snake.dashGauge + 0.5);
      }
    });

    // 3. INTEGRATE BOT STEERING AI
    s.snakes.forEach((snake) => {
      if (!snake.isBot) return;

      // Bot periodic decisions
      if (Math.random() < 0.02) {
        // Look for the closest food target
        let closestFood: Fruit | null = null;
        let minDist = 600;

        s.fruits.forEach((fruit) => {
          const dx = fruit.x - snake.segments[0].x;
          const dy = fruit.y - snake.segments[0].y;
          const dist = Math.hypot(dx, dy);
          if (dist < minDist) {
            minDist = dist;
            closestFood = fruit;
          }
        });

        if (closestFood) {
          const fObj = closestFood as Fruit;
          // Steer directly towards food coordinate
          const head = snake.segments[0];
          snake.targetAngle = Math.atan2(fObj.y - head.y, fObj.x - head.x);
        } else {
          // Wander randomly
          snake.targetAngle += (Math.random() * 2 - 1) * 0.8;
        }

        // Random bot boost spikes chased after high fruits
        snake.isBoosting = Math.random() < 0.15 && snake.score > 250;
      }

      // SENSORY BOT RAYCAST DODGE: Check if bot is about to crash into stones or other snake boundaries
      const botHead = snake.segments[0];
      let aboutToCollide = false;
      let escapeAngle = 0;

      // A. Dodge stones
      s.obstacles.forEach((obs) => {
        const dx = obs.x - botHead.x;
        const dy = obs.y - botHead.y;
        const dist = Math.hypot(dx, dy);
        if (dist < obs.radius + 80) {
          aboutToCollide = true;
          // Calculate vector pointing away from obstacle
          escapeAngle = Math.atan2(-dy, -dx) + (Math.random() * 0.4 - 0.2);
        }
      });

      // B. Dodge other snakes' segments (vital to slither bot intelligence)
      s.snakes.forEach((other) => {
        if (other.isDead) return;
        
        // Don't detect collision with own head segments
        other.segments.forEach((seg, idx) => {
          if (other.id === snake.id && idx < 6) return; // skip own neck

          const dx = seg.x - botHead.x;
          const dy = seg.y - botHead.y;
          const dist = Math.hypot(dx, dy);
          if (dist < 70) {
            aboutToCollide = true;
            // Repel drastically
            escapeAngle = Math.atan2(-dy, -dx) + (Math.random() * 1.5 - 0.75);
          }
        });
      });

      // C. Safe repelling against raw arena boundaries
      const distFromLeft = botHead.x;
      const distFromRight = WORLD_SIZE - botHead.x;
      const distFromTop = botHead.y;
      const distFromBottom = WORLD_SIZE - botHead.y;

      if (distFromLeft < 150) {
        snake.targetAngle = 0; // go right
      } else if (distFromRight < 150) {
        snake.targetAngle = Math.PI; // go left
      } else if (distFromTop < 150) {
        snake.targetAngle = Math.PI / 2; // go down
      } else if (distFromBottom < 150) {
        snake.targetAngle = -Math.PI / 2; // go up
      } else if (aboutToCollide) {
        // Blend escape angle swiftly
        snake.targetAngle = escapeAngle;
      }
    });

    // 4. ANIMATE & MOVEMENT SMOOTHING
    s.snakes.forEach((snake) => {
      if (snake.isDead) return;

      // Smooth segment angle rotation towards target angle smoothly
      let dAngle = snake.targetAngle - snake.currentAngle;
      // Isolate wrapping range issues
      while (dAngle < -Math.PI) dAngle += Math.PI * 2;
      while (dAngle > Math.PI) dAngle -= Math.PI * 2;

      // Adjust turn speed
      const turnRate = 0.15; 
      snake.currentAngle += dAngle * turnRate;

      // Move snake head coordinate
      const head = snake.segments[0];
      const prevHeadX = head.x;
      const prevHeadY = head.y;

      head.x += Math.cos(snake.currentAngle) * snake.speed;
      head.y += Math.sin(snake.currentAngle) * snake.speed;
      head.angle = snake.currentAngle;

      // Boundary check clamp constraints
      if (head.x < 0) head.x = 0;
      if (head.x > WORLD_SIZE) head.x = WORLD_SIZE;
      if (head.y < 0) head.y = 0;
      if (head.y > WORLD_SIZE) head.y = WORLD_SIZE;

      // Push interpolation through body chains with spring-damper offsets
      const followDist = 14; // distance density between nodes
      for (let j = 1; j < snake.segments.length; j++) {
        const parent = snake.segments[j - 1];
        const current = snake.segments[j];
        const dx = parent.x - current.x;
        const dy = parent.y - current.y;
        const dist = Math.hypot(dx, dy) || 1;

        // Enforce exact lock-step spacing layout to prevent staccato visual stuttering
        const ratio = followDist / dist;
        current.x = parent.x - dx * ratio;
        current.y = parent.y - dy * ratio;
        current.angle = Math.atan2(dy, dx);
      }
    });

    // 5. UPDATE FRUIT COLLISION DETECTION & MAGNETIC ACCELERATION
    const playerHead = playerSnake.segments[0];
    const isPlayerMagnetActive = playerSnake.powerUps.magnet > 0;

    s.fruits.forEach((fruit, fIdx) => {
      // Render magnetism pull animation towards the player
      if (isPlayerMagnetActive) {
        const dx = playerHead.x - fruit.x;
        const dy = playerHead.y - fruit.y;
        const dist = Math.hypot(dx, dy);

        if (dist < 250) {
          // Accelerate fruits towards center of neck
          const speedFactor = 12 * (1 - dist / 250);
          fruit.headingX = (dx / dist) * speedFactor;
          fruit.headingY = (dy / dist) * speedFactor;
          fruit.x += fruit.headingX;
          fruit.y += fruit.headingY;
        }
      }

      // Check collision with ALL active organic snakes
      s.snakes.forEach((snake) => {
        if (snake.isDead) return;
        const sHead = snake.segments[0];
        const foodDist = Math.hypot(sHead.x - fruit.x, sHead.y - fruit.y);

        // Multi segment buffer size of head
        const headRadius = 25; 
        if (foodDist < headRadius + 5) {
          // Eat fruit!
          snake.score += fruit.value;

          // Sound cues
          if (snake.id === s.playerSnakeId) {
            soundRef.current?.playEat();
            onFruitEaten();
            setQuestCount((v) => Math.min(questGoal, v + 1));
          }

          // Trigger screen popups for major items
          if (snake.id === s.playerSnakeId && fruit.value >= 30) {
            s.popups.push({
              id: `popup_${Math.random()}`,
              x: fruit.x,
              y: fruit.y - 30,
              text: `+${fruit.value}`,
              color: fruit.type === 'shield' ? '#10b981' : fruit.type === 'magnet' ? '#3b82f6' : '#ec4899',
              alpha: 1.0,
              scale: 1.2,
              life: 50,
            });
          }

          // Powerup buff attachments
          if (fruit.type === 'magnet') {
            snake.powerUps.magnet = 400; // 400 frames
            if (snake.id === s.playerSnakeId) soundRef.current?.playPowerup();
          } else if (fruit.type === 'shield') {
            snake.powerUps.shield = 450;
            if (snake.id === s.playerSnakeId) soundRef.current?.playPowerup();
          } else if (fruit.type === 'lightning') {
            snake.powerUps.boost = 300;
            if (snake.id === s.playerSnakeId) soundRef.current?.playPowerup();
          }

          // Spawn splash particles
          const splatColor = SKINS[snake.skin]?.colors.primary || '#eab308';
          for (let p = 0; p < 8; p++) {
            s.particles.push({
              id: `part_${Math.random()}`,
              x: fruit.x,
              y: fruit.y,
              vx: (Math.random() * 2 - 1) * 3,
              vy: (Math.random() * 2 - 1) * 3,
              color: splatColor,
              size: 2 + Math.random() * 4,
              alpha: 1.0,
              life: 25 + Math.random() * 15,
              maxLife: 40,
            });
          }

          // Grow snake segments based on score sizing thresholds
          const segCountNeeded = Math.floor(snake.score / 15) + 6;
          while (snake.segments.length < segCountNeeded) {
            const tail = snake.segments[snake.segments.length - 1];
            snake.segments.push({
              x: tail ? tail.x : sHead.x,
              y: tail ? tail.y : sHead.y,
              angle: tail ? tail.angle : snake.currentAngle,
              scale: 0.1, // animate entrance scale
            });
          }

          // Delete from global list
          s.fruits.splice(fIdx, 1);
          // Spawn replacements
          spawnRandomFruit(false);
        }
      });
    });

    // 6. COLLISION SYSTEM: SNAKE TO OBSTACLE OR SNAKE TO SNAKE CRASHES
    s.snakes.forEach((snake) => {
      if (snake.isDead) return;
      const head = snake.segments[0];

      // A. Check Rock Obstacle Collisions
      s.obstacles.forEach((obs) => {
        const dist = Math.hypot(head.x - obs.x, head.y - obs.y);
        if (dist < obs.radius + 18) {
          // If shield is active, block collision and push snake away
          if (snake.powerUps.shield > 0) {
            snake.powerUps.shield = 0; // consume protection
            const bounceAngle = Math.atan2(head.y - obs.y, head.x - obs.x);
            head.x = obs.x + Math.cos(bounceAngle) * (obs.radius + 28);
            head.y = obs.y + Math.sin(bounceAngle) * (obs.radius + 28);
            snake.targetAngle = bounceAngle;
            // Generate visual spark blocks
            return;
          }

          killSnake(snake);
        }
      });

      // B. Body segments intersection of other snakes
      s.snakes.forEach((other) => {
        if (other.isDead || snake.isDead) return;

        other.segments.forEach((seg, idx) => {
          // Avoid triggering crash against self entirely (allow overlapping own body)
          if (snake.id === other.id) return;

          const dist = Math.hypot(head.x - seg.x, head.y - seg.y);
          if (dist < 23) {
            // Shield protector bounce blocks
            if (snake.powerUps.shield > 0) {
              snake.powerUps.shield = 0; // consume
              const pushBack = Math.atan2(head.y - seg.y, head.x - seg.x);
              head.x += Math.cos(pushBack) * 35;
              head.y += Math.sin(pushBack) * 35;
              snake.targetAngle = pushBack;
              return;
            }

            killSnake(snake);
          }
        });
      });
    });

    // 7. PARTICLES AND POPUPS DECAY LOOP
    s.particles.forEach((part, idx) => {
      part.x += part.vx;
      part.y += part.vy;
      part.life--;
      part.alpha = Math.max(0, part.life / part.maxLife);
      if (part.life <= 0) s.particles.splice(idx, 1);
    });

    s.popups.forEach((pop, idx) => {
      pop.y -= 0.6; // fly upwards
      pop.life--;
      pop.alpha = Math.max(0, pop.life / 50);
      if (pop.life <= 0) s.popups.splice(idx, 1);
    });

    // 8. RANKINGS & SCORE STATISTICS
    // Sort active snakes
    const sorted = [...s.snakes]
      .filter((sn) => !sn.isDead)
      .sort((a, b) => b.score - a.score);

    // Apply ranking tiers
    sorted.forEach((sn, index) => {
      sn.rank = index + 1;
    });

    // Sync leaderboard react states
    const topBoard = sorted.slice(0, 5).map((sn) => ({
      name: sn.name || 'Bot',
      score: sn.score,
      skin: sn.skin,
      isPlayer: sn.id === s.playerSnakeId,
    }));
    setLeaderboard(topBoard);

    const matchPlayer = sorted.find((sn) => sn.id === s.playerSnakeId);
    if (matchPlayer) {
      setPlayerScore(matchPlayer.score);
      setPlayerRank(matchPlayer.rank);
    }

    // 9. CAMERA SMOOTH TRACKING Interpolating to center Player
    const playerRef = s.snakes.find((sn) => sn.id === s.playerSnakeId);
    if (playerRef) {
      const pHead = playerRef.segments[0];
      const cameraRate = playerRef.isBoosting ? 0.12 : 0.08; // smooth follow adaptive
      s.camera.x += (pHead.x - s.camera.x) * cameraRate;
      s.camera.y += (pHead.y - s.camera.y) * cameraRate;
    }

    // Decays state camera shake
    if (s.shakeStrength > 0) {
      s.shakeStrength *= 0.92;
      if (s.shakeStrength < 0.2) s.shakeStrength = 0;
    }
  };

  const killSnake = (snake: Snake) => {
    const s = stateRef.current;
    if (snake.isDead) return;
    snake.isDead = true;

    // Trigger explosive audio crash
    soundRef.current?.playDeath();

    // Spawn massive explosion particles
    const skinColors = SKINS[snake.skin]?.colors;
    const bodyColor = skinColors?.primary || '#ef4444';

    s.shakeStrength = snake.id === s.playerSnakeId ? 18 : 6;

    snake.segments.forEach((seg) => {
      // Spawn fruits in place of dissolved body coordinates (Slither.io mechanics)
      if (Math.random() < 0.6) {
        spawnRandomFruit(true, { x: seg.x + (Math.random() * 24 - 12), y: seg.y + (Math.random() * 24 - 12) });
      }

      // Decorative vector flame dots
      for (let i = 0; i < 4; i++) {
        s.particles.push({
          id: `part_${Math.random()}`,
          x: seg.x,
          y: seg.y,
          vx: (Math.random() * 2 - 1) * 4,
          vy: (Math.random() * 2 - 1) * 4,
          color: Math.random() > 0.5 ? bodyColor : skinColors?.secondary || '#db2777',
          size: 4 + Math.random() * 6,
          alpha: 1.0,
          life: 40 + Math.random() * 20,
          maxLife: 60,
        });
      }
    });

    // If player died, trigger game-over routine
    if (snake.id === s.playerSnakeId) {
      setTimeout(() => {
        onGameOver(snake.score);
      }, 1500);
    } else {
      // Respawn Bot snake to keep world populated
      setTimeout(() => {
        respawnBot(snake);
      }, 3000);
    }
  };

  const respawnBot = (oldBot: Snake) => {
    const s = stateRef.current;
    // delete previous bot ref
    const idx = s.snakes.findIndex((sn) => sn.id === oldBot.id);
    if (idx !== -1) {
      s.snakes.splice(idx, 1);
    }

    // recreate a brand new one
    const randX = 300 + Math.random() * (WORLD_SIZE - 600);
    const randY = 300 + Math.random() * (WORLD_SIZE - 600);
    const botSegments = [];
    const botLen = 10 + Math.floor(Math.random() * 10);
    const botAngle = Math.random() * Math.PI * 2;

    for (let j = 0; j < botLen; j++) {
      botSegments.push({
        x: randX - Math.cos(botAngle) * j * 16,
        y: randY - Math.sin(botAngle) * j * 16,
        angle: botAngle,
        scale: 1.0,
      });
    }

    const botSkins: SkinType[] = ['apple', 'mango', 'grape', 'kiwi', 'orange', 'strawberry'];
    const botNames = [
      'GlitterGlow', 'MangoMania', 'AppleAce', 'BerryBlast', 'PineapplePal',
      'DragonFruit', 'RulerMelon', 'LemonLord', 'CantaloupeKing'
    ];

    s.snakes.push({
      id: `bot_${Math.random()}`,
      name: botNames[Math.floor(Math.random() * botNames.length)],
      isBot: true,
      skin: botSkins[Math.floor(Math.random() * botSkins.length)],
      segments: botSegments,
      speed: 3 + Math.random() * 1.5,
      targetAngle: botAngle,
      currentAngle: botAngle,
      score: botLen * 10,
      isBoosting: false,
      isDead: false,
      rank: s.snakes.length + 1,
      powerUps: { magnet: 0, shield: 0, boost: 0 },
      dashGauge: 100,
    });
  };

  // --- CORE CANVAS VECTOR RENDERING ENGINE ---
  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Direct resolution fits to client window boundaries dynamically
    const width = containerRef.current?.clientWidth || window.innerWidth;
    const height = containerRef.current?.clientHeight || window.innerHeight;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    const s = stateRef.current;

    // Apply Screen Shake vector offsets
    ctx.save();
    if (s.shakeStrength > 0.1) {
      const sx = (Math.random() * 2 - 1) * s.shakeStrength;
      const sy = (Math.random() * 2 - 1) * s.shakeStrength;
      ctx.translate(sx, sy);
    }

    // Clear Screen Backspace
    ctx.fillStyle = '#0c0a09';
    ctx.fillRect(0, 0, width, height);

    // Coordinate space translated in negative camera viewoffsets
    const camX = s.camera.x;
    const camY = s.camera.y;
    const centerX = width / 2;
    const centerY = height / 2;

    // 1. DRAW TILE-PATTERN RANDOMLY REPEATED FLOOR
    if (patternCanvasRef.current) {
      ctx.save();
      // Translate pattern pattern in alignment inside world coordinate grid
      const pattern = ctx.createPattern(patternCanvasRef.current, 'repeat');
      if (pattern) {
        ctx.fillStyle = pattern;
        ctx.beginPath();
        // Paint spacious localized bounding rectangle
        ctx.translate(centerX - camX, centerY - camY);
        ctx.fillRect(0, 0, WORLD_SIZE, WORLD_SIZE);
      }
      ctx.restore();
    }

    // Draw boundary border fence outline
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 15;
    ctx.shadowColor = '#dc2626';
    ctx.shadowBlur = 25;
    ctx.strokeRect(centerX - camX, centerY - camY, WORLD_SIZE, WORLD_SIZE);
    ctx.shadowBlur = 0; // reset

    // 2. DRAW ROCK OBSTACLES
    s.obstacles.forEach((obs) => {
      // Cull items outside camera sight frame to optimize frame rendering
      const scrX = obs.x - camX + centerX;
      const scrY = obs.y - camY + centerY;
      if (scrX < -250 || scrX > width + 250 || scrY < -250 || scrY > height + 250) return;

      ctx.save();
      ctx.translate(scrX, scrY);

      // Shadow drop
      ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
      ctx.shadowBlur = 12;
      ctx.shadowOffsetY = 8;

      if (obs.type === 'magma') {
        const radGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, Math.max(0.1, obs.radius));
        radGrad.addColorStop(0, '#f97316');
        radGrad.addColorStop(0.3, '#dc2626');
        radGrad.addColorStop(1, '#1c1917');
        ctx.fillStyle = radGrad;
        ctx.strokeStyle = '#f97316';
        ctx.lineWidth = 2.5;
        ctx.shadowColor = '#f97316';
        ctx.shadowBlur = 8;
      } else if (obs.type === 'crystal') {
        const radGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, Math.max(0.1, obs.radius));
        radGrad.addColorStop(0, '#a855f7');
        radGrad.addColorStop(0.5, '#6b21a8');
        radGrad.addColorStop(1, '#0c0a09');
        ctx.fillStyle = radGrad;
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 2.5;
        ctx.shadowColor = '#c084fc';
        ctx.shadowBlur = 12;
      } else {
        const radGrad = ctx.createRadialGradient(-obs.radius * 0.3, -obs.radius * 0.3, 0, 0, 0, Math.max(0.1, obs.radius));
        radGrad.addColorStop(0, '#78716c');
        radGrad.addColorStop(0.5, '#44403c');
        radGrad.addColorStop(1, '#1c1917');
        ctx.fillStyle = radGrad;
        ctx.strokeStyle = '#292524';
        ctx.lineWidth = 3;
      }

      // Draw custom organic bumpy polygonal boulder instead of regular circle
      ctx.beginPath();
      const numPoints = 8;
      const points: Position[] = [];
      for (let i = 0; i < numPoints; i++) {
        const angle = (i * Math.PI * 2) / numPoints;
        const wiggle = Math.sin(angle * 3) * (obs.radius * 0.12);
        const r = obs.radius + wiggle;
        points.push({ x: Math.cos(angle) * r, y: Math.sin(angle) * r });
      }
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < numPoints; i++) {
        ctx.lineTo(points[i].x, points[i].y);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.restore();
    });

    // 3. DRAW FRUIT ITEMS (with soft pulsing and item icons)
    s.fruits.forEach((fruit) => {
      const scrX = fruit.x - camX + centerX;
      const scrY = fruit.y - camY + centerY;
      // Cull optimized frame bounds
      if (scrX < -100 || scrX > width + 100 || scrY < -100 || scrY > height + 100) return;

      ctx.save();
      ctx.translate(scrX, scrY);

      // Pulse calculations
      const pulse = Math.sin(s.gameTime * 0.005 + fruit.pulseOffset) * 0.08;
      const actualScale = fruit.scale * (1 + pulse);
      ctx.scale(actualScale, actualScale);

      // Glow halo surrounding fruits
      ctx.shadowColor = fruit.glowColor;
      ctx.shadowBlur = 14;

      // Draw fruit designs
      if (fruit.type === 'apple') {
        // Red fruit body
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        // Slightly heart-shaped apple
        ctx.arc(-4, 0, 9, 0, Math.PI * 2);
        ctx.arc(4, 0, 9, 0, Math.PI * 2);
        ctx.arc(0, 5, 8, 0, Math.PI * 2);
        ctx.fill();

        // Glossy bubble accent
        ctx.fillStyle = 'rgba(255,255,255,0.45)';
        ctx.beginPath();
        ctx.arc(-3, -3, 3, 0, Math.PI * 2);
        ctx.fill();

        // Leaf outline
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.ellipse(0, -9, 4, 2, -Math.PI / 6, 0, Math.PI * 2);
        ctx.fill();
      } else if (fruit.type === 'grape') {
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.arc(0, 4, 6, 0, Math.PI * 2);
        ctx.arc(-5, -2, 5, 0, Math.PI * 2);
        ctx.arc(5, -2, 5, 0, Math.PI * 2);
        ctx.arc(0, -6, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#22c55e'; // grape stem
        ctx.fillRect(-1, -11, 2, 4);
      } else if (fruit.type === 'orange') {
        ctx.fillStyle = '#ff9100';
        ctx.beginPath();
        ctx.arc(0, 0, 9, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fff4e6';
        ctx.beginPath();
        ctx.arc(0, 0, 7.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ff9100';
        // slice lines
        for (let i = 0; i < 4; i++) {
          ctx.save();
          ctx.rotate((i * Math.PI) / 4);
          ctx.fillRect(-1, -7, 2, 14);
          ctx.restore();
        }
      } else if (fruit.type === 'strawberry') {
        ctx.fillStyle = '#ec4899';
        ctx.beginPath();
        ctx.moveTo(0, 10);
        ctx.bezierCurveTo(-10, 2, -8, -8, 0, -8);
        ctx.bezierCurveTo(8, -8, 10, 2, 0, 10);
        ctx.fill();

        // Seeds
        ctx.fillStyle = '#fde047';
        ctx.fillRect(-3, -2, 1, 1.5);
        ctx.fillRect(3, -2, 1, 1.5);
        ctx.fillRect(0, 2, 1, 1.5);

        // Leafs
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(-3, -8, 3, 0, Math.PI * 2);
        ctx.arc(3, -8, 3, 0, Math.PI * 2);
        ctx.fill();
      } else if (fruit.type === 'magnet') {
        // Special Magnet Buff icon
        ctx.fillStyle = '#2563eb';
        ctx.beginPath();
        ctx.arc(0, 0, 12, 0, Math.PI * 2);
        ctx.fill();

        // draw U-character representation
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(0, -2, 5, 0, Math.PI, false);
        ctx.stroke();

        ctx.fillStyle = '#dc2626'; // RED poles
        ctx.fillRect(-6.5, -4, 3, 3);
        ctx.fillRect(3.5, -4, 3, 3);
      } else if (fruit.type === 'shield') {
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(0, 0, 12, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
         // draw visual shield icon
        ctx.beginPath();
        ctx.moveTo(0, -6);
        ctx.lineTo(5, -4);
        ctx.lineTo(4, 2);
        ctx.bezierCurveTo(2, 6, -2, 6, -4, 2);
        ctx.lineTo(-5, -4);
        ctx.closePath();
        ctx.fill();
      } else if (fruit.type === 'lightning') {
        ctx.fillStyle = '#eab308';
        ctx.beginPath();
        ctx.arc(0, 0, 12, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        // lightning bolt
        ctx.beginPath();
        ctx.moveTo(1, -7);
        ctx.lineTo(-5, 0);
        ctx.lineTo(-1, 0);
        ctx.lineTo(-2, 7);
        ctx.lineTo(5, -1);
        ctx.lineTo(1, -1);
        ctx.closePath();
        ctx.fill();
      } else {
        // generic yellow cherry/pearl
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(0, 0, 7.5, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    });

    // 4. DRAW CO-MULTIPLAYER ORGANIC SNAKES (From tail up to head)
    s.snakes.forEach((snake) => {
      if (snake.isDead) return;

      const skinColors = SKINS[snake.skin]?.colors;
      const primaryColor = skinColors?.primary || '#ef4444';
      const secondaryColor = skinColors?.secondary || '#dc2626';

      // Power shields highlight glow
      const isShielded = snake.powerUps.shield > 0;
      const isMagnet = snake.powerUps.magnet > 0;

      // Draw Glowing Shadows for segments specifically
      ctx.save();

      // Loop and render bodies starting back to tail index
      const len = snake.segments.length;
      for (let idx = len - 1; idx >= 0; idx--) {
        const seg = snake.segments[idx];
        const scrX = seg.x - camX + centerX;
        const scrY = seg.y - camY + centerY;

        // Optimized camera bounding cull
        if (scrX < -150 || scrX > width + 150 || scrY < -150 || scrY > height + 150) continue;

        ctx.save();
        ctx.translate(scrX, scrY);
        ctx.rotate(seg.angle);

        // Body scale sweling animations or gradient segment diameters
        const baseSize = 13 + Math.sin(idx * 0.15 + s.gameTime * 0.006) * 1.5;
        // progressive thinning towards the tail
        const tapering = idx === 0 ? 1.0 : Math.max(0.45, 1 - (idx / len) * 0.6);
        let segmentRadius = baseSize * tapering;

        // Soft scale grow animations on birth segment entries
        if (seg.scale < 0.99) {
          seg.scale += (1 - seg.scale) * 0.1;
          segmentRadius *= seg.scale;
        }

        // Draw individual segment skins
        const radialGrad = ctx.createRadialGradient(
          -segmentRadius * 0.25,
          -segmentRadius * 0.25,
          0,
          0,
          0,
          segmentRadius
        );

        if (snake.skin === 'kiwi') {
          // outer fuzzy brown shell
          ctx.fillStyle = '#78350f';
          ctx.beginPath();
          ctx.arc(0, 0, segmentRadius, 0, Math.PI * 2);
          ctx.fill();

          // Green sliced inner core
          ctx.fillStyle = '#84cc16';
          ctx.beginPath();
          ctx.arc(0, 0, segmentRadius * 0.8, 0, Math.PI * 2);
          ctx.fill();

          // small yellow white seed dots center representation
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(0, 0, segmentRadius * 0.25, 0, Math.PI * 2);
          ctx.fill();

          // micro black dots seeds
          ctx.fillStyle = '#1c1917';
          for (let d = 0; d < 6; d++) {
            const seedAng = (d * Math.PI) / 3;
            const sx = Math.cos(seedAng) * segmentRadius * 0.45;
            const sy = Math.sin(seedAng) * segmentRadius * 0.45;
            ctx.fillRect(sx - 1, sy - 1, 2, 2);
          }
        } else if (snake.skin === 'grape') {
          // bubble pearl purple glass styles
          radialGrad.addColorStop(0, '#d8b4fe');
          radialGrad.addColorStop(0.4, primaryColor);
          radialGrad.addColorStop(1, secondaryColor);
          ctx.fillStyle = radialGrad;
          ctx.beginPath();
          ctx.arc(0, 0, segmentRadius, 0, Math.PI * 2);
          ctx.fill();

          // little shiny white glare bubble
          ctx.fillStyle = 'rgba(255,255,255,0.45)';
          ctx.beginPath();
          ctx.arc(-segmentRadius * 0.3, -segmentRadius * 0.3, segmentRadius * 0.2, 0, Math.PI * 2);
          ctx.fill();
        } else if (snake.skin === 'mango') {
          // orange yellow gradient shifts
          radialGrad.addColorStop(0, '#fef08a'); // golden mango shine
          radialGrad.addColorStop(0.3, '#f97316');
          radialGrad.addColorStop(1, '#ea580c');
          ctx.fillStyle = radialGrad;
          ctx.beginPath();
          ctx.arc(0, 0, segmentRadius, 0, Math.PI * 2);
          ctx.fill();

          // green leaf outline on alternate segments
          if (idx % 4 === 0) {
            ctx.fillStyle = '#22c55e';
            ctx.beginPath();
            ctx.ellipse(0, -segmentRadius * 1.0, segmentRadius * 0.3, segmentRadius * 0.15, Math.PI/4, 0, Math.PI*2);
            ctx.fill();
          }
        } else if (snake.skin === 'apple') {
          // glossy red delicious apple skin
          radialGrad.addColorStop(0, '#fca5a5');
          radialGrad.addColorStop(0.3, primaryColor);
          radialGrad.addColorStop(1, secondaryColor);
          ctx.fillStyle = radialGrad;
          ctx.beginPath();
          ctx.arc(0, 0, segmentRadius, 0, Math.PI * 2);
          ctx.fill();

          // white glossy spot
          ctx.fillStyle = 'rgba(255,255,255,0.5)';
          ctx.beginPath();
          ctx.arc(-segmentRadius * 0.3, -segmentRadius * 0.3, segmentRadius * 0.22, 0, Math.PI * 2);
          ctx.fill();
        } else {
          // fallback gradient skins
          radialGrad.addColorStop(0, '#ffffff');
          radialGrad.addColorStop(0.4, primaryColor);
          radialGrad.addColorStop(1, secondaryColor);
          ctx.fillStyle = radialGrad;
          ctx.beginPath();
          ctx.arc(0, 0, segmentRadius, 0, Math.PI * 2);
          ctx.fill();
        }

        // BOOST HALO: trailing light rings if speeding
        if (snake.isBoosting && idx % 3 === 0) {
          ctx.strokeStyle = primaryColor;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(0, 0, segmentRadius * 1.35, 0, Math.PI * 2);
          ctx.stroke();
        }

        ctx.restore();
      }

      // 5. DRAW HEAD DETAILS AND DECORATIONS
      const head = snake.segments[0];
      const hX = head.x - camX + centerX;
      const hY = head.y - camY + centerY;

      ctx.save();
      ctx.translate(hX, hY);
      ctx.rotate(snake.currentAngle);

      // Render glowing buffer rings if shield/magnet are active
      if (isShielded) {
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 3;
        ctx.shadowColor = '#10b981';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(0, 0, 32, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0; // reset
      }

      if (isMagnet) {
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.arc(0, 0, 38, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]); // clear
      }

      // Draw larger Head base
      const headRadius = 23;
      const headGrad = ctx.createRadialGradient(-5, -5, 0, 0, 0, headRadius);
      headGrad.addColorStop(0, '#fca5a5');
      headGrad.addColorStop(0.3, primaryColor);
      headGrad.addColorStop(1, secondaryColor);
      ctx.fillStyle = headGrad;
      ctx.beginPath();
      ctx.arc(0, 0, headRadius, 0, Math.PI * 2);
      ctx.fill();

      // Shiny glare spot
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.beginPath();
      ctx.arc(-6, -6, 5, 0, Math.PI * 2);
      ctx.fill();

      // Green leafy branch stem on top of head
      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.ellipse(-10, -headRadius + 2, 7, 3.5, 0.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#78350f'; // brown segment stem
      ctx.fillRect(-2, -headRadius - 3, 3, 5);

      // Cute animated anime eyeballs
      const eyeOffset = 8;
      const eyeRadius = 6.2;
      const pupilRadius = 3.5;

      // Draw Left / Right Eye coordinates
      const drawEye = (ex: number, ey: number) => {
        ctx.save();
        ctx.translate(ex, ey);

        // white backdrop
        ctx.fillStyle = '#ffffff';
         ctx.beginPath();
        ctx.arc(0, 0, eyeRadius, 0, Math.PI * 2);
        ctx.fill();

        // responsive pupil looking towards steering target angle
        ctx.fillStyle = '#1c1917';
        ctx.beginPath();
        ctx.arc(1.5, 0, pupilRadius, 0, Math.PI * 2);
        ctx.fill();

        // sweet sparkles
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0.5, -1, 1.2, 0, Math.PI * 2);
        ctx.fill();

        // blush cheeks
        ctx.fillStyle = 'rgba(251,113,133,0.45)';
        ctx.beginPath();
        ctx.ellipse(0, 7, 4, 1.8, 0, 0, Math.PI*2);
        ctx.fill();

        ctx.restore();
      };

      // Left eye
      drawEye(8, -eyeOffset);
      // Right eye
      drawEye(8, eyeOffset);

      // Joyous anime smile
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 1.8;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(13, 0, 3, 0, Math.PI, false); // happy U mouth
      ctx.stroke();

      // Label Tags above coordinates
      ctx.restore(); // out of currentAngle

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      
      // Highlight the main player name uniquely with neon badges
      if (snake.id === s.playerSnakeId) {
        ctx.fillStyle = '#fbbf24'; // GOLD tag
      } else {
        ctx.fillStyle = '#e7e5e4';
      }
      ctx.fillText(`${snake.name} (${snake.score})`, hX, hY - headRadius - 15);

      // KING AND QUEEN CROWNS (Ranking system visual representations)
      if (snake.rank === 1) {
        // Draw Golden King Crown bouncing above head
        ctx.save();
        const bX = hX;
        const bY = hY - headRadius - 36 + Math.sin(s.gameTime * 0.007) * 4;
        ctx.translate(bX, bY);

        ctx.fillStyle = '#fbbf24'; // Gold
        ctx.strokeStyle = '#d97706';
        ctx.lineWidth = 1.5;
        // Glow
        ctx.shadowColor = '#fbbf24';
        ctx.shadowBlur = 10;

        ctx.beginPath();
        ctx.moveTo(-12, 10);
        ctx.lineTo(12, 10);
        ctx.lineTo(15, -4);
        ctx.lineTo(7, 3);
        ctx.lineTo(0, -10); // high center spike
        ctx.lineTo(-7, 3);
        ctx.lineTo(-15, -4);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // crown pearls
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(0, -12, 2.5, 0, Math.PI * 2);
        ctx.arc(-15, -6, 2, 0, Math.PI * 2);
        ctx.arc(15, -6, 2, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      } else if (snake.rank === 2) {
        // Draw Ruby Queen Crown bobbing
        ctx.save();
        const bX = hX;
        const bY = hY - headRadius - 32 + Math.sin(s.gameTime * 0.007 + Math.PI) * 3;
        ctx.translate(bX, bY);

        ctx.fillStyle = '#e2e8f0'; // Silver
        ctx.strokeStyle = '#475569';
        ctx.lineWidth = 1.5;
        // Queen ruby color
        ctx.shadowColor = '#ec4899';
        ctx.shadowBlur = 8;

        ctx.beginPath();
        ctx.moveTo(-9, 8);
        ctx.lineTo(9, 8);
        ctx.lineTo(11, -2);
        ctx.lineTo(4, 3);
        ctx.lineTo(0, -6);
        ctx.lineTo(-4, 3);
        ctx.lineTo(-11, -2);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#ec4899'; // Ruby centerpiece!
        ctx.beginPath();
        ctx.arc(0, 8, 2, 0, Math.PI * 2);
        ctx.arc(0, -8, 1.8, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      }
    });

    ctx.restore(); // stop global camera translating context offset

    // 6. DRAW FLOATING PARTICLES (explosions and Splashes)
    s.particles.forEach((part) => {
      const scrX = part.x - camX + centerX;
      const scrY = part.y - camY + centerY;
      if (scrX < -20 || scrX > width + 20 || scrY < -20 || scrY > height + 20) return;

      ctx.save();
      ctx.globalAlpha = part.alpha;
      ctx.fillStyle = part.color;
      ctx.beginPath();
      ctx.arc(scrX, scrY, part.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });

    // 7. DRAW FLOATING POPUPS STATS
    s.popups.forEach((pop) => {
      const scrX = pop.x - camX + centerX;
      const scrY = pop.y - camY + centerY;
      if (scrX < -40 || scrX > width + 40 || scrY < -40 || scrY > height + 40) return;

      ctx.save();
      ctx.globalAlpha = pop.alpha;
      ctx.fillStyle = pop.color;
      ctx.font = 'extrabold 15px sans-serif';
      ctx.textAlign = 'center';
      
      // Outline
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 3;
      ctx.strokeText(pop.text, scrX, scrY);
      ctx.fillText(pop.text, scrX, scrY);

      ctx.restore();
    });

    // 8. MINIMAP REDIRECTION GAUGE (Top Left Circular Radar)
    drawMinimap(ctx, width, height);

    // 9. DRAW PREMIUM VIRTUAL JOYSTICK FOR MOBILE
    if (s.showJoystick && s.joystickStart && s.joystickCurrent) {
      const startX = s.joystickStart.x;
      const startY = s.joystickStart.y;
      const currX = s.joystickCurrent.x;
      const currY = s.joystickCurrent.y;
      
      const dx = currX - startX;
      const dy = currY - startY;
      const dist = Math.hypot(dx, dy);
      
      const maxRadius = 45;
      let knobX = currX;
      let knobY = currY;
      
      if (dist > maxRadius) {
        const ratio = maxRadius / dist;
        knobX = startX + dx * ratio;
        knobY = startY + dy * ratio;
      }
      
      ctx.save();
      
      // Outer glassy ring with dynamic glowing aura
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)'; // Amber outline
      ctx.fillStyle = 'rgba(12, 10, 9, 0.45)'; // Transparent obsidian center
      ctx.lineWidth = 3;
      ctx.shadowColor = 'rgba(245, 158, 11, 0.25)';
      ctx.shadowBlur = 12;
      
      ctx.beginPath();
      ctx.arc(startX, startY, maxRadius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      
      // Draw inner steering guide lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(startX - maxRadius + 8, startY);
      ctx.lineTo(startX + maxRadius - 8, startY);
      ctx.moveTo(startX, startY - maxRadius + 8);
      ctx.lineTo(startX, startY + maxRadius - 8);
      ctx.stroke();
      
      // Inner glowing metallic thumb knob
      const knobGrad = ctx.createRadialGradient(knobX, knobY, 0, knobX, knobY, 18);
      knobGrad.addColorStop(0, '#fef08a'); // Soft yellow core
      knobGrad.addColorStop(0.3, '#fbbf24'); // Radiant amber mid
      knobGrad.addColorStop(1, '#cb5a07'); // Deep burning orange metal edge
      
      ctx.fillStyle = knobGrad;
      ctx.strokeStyle = 'rgba(254, 240, 138, 0.8)';
      ctx.lineWidth = 1.5;
      ctx.shadowColor = 'rgba(245, 158, 11, 0.5)';
      ctx.shadowBlur = 15;
      
      ctx.beginPath();
      ctx.arc(knobX, knobY, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      
      ctx.restore();
    }
  };

  // Render highly functional vector Minimap (bounding coordinates of active player chains + bots)
  const drawMinimap = (ctx: CanvasRenderingContext2D, sWidth: number, sHeight: number) => {
    const s = stateRef.current;
    
    // Minimap boundary parameters matches Slither circular compass HUD
    const mmSize = 110;
    const padding = 16;
    const mmX = mmSize / 2 + padding;
    const mmY = mmSize / 2 + padding + 60; // offset down past quest header

    ctx.save();
    ctx.translate(mmX, mmY);

    // Background circle container
    ctx.fillStyle = 'rgba(12, 10, 9, 0.75)';
    ctx.strokeStyle = 'rgba(249, 115, 22, 0.25)';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = '#000000';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(0, 0, mmSize / 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0; // clear

    // Overlay boundary radar grid lines
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-mmSize / 2, 0); ctx.lineTo(mmSize / 2, 0);
    ctx.moveTo(0, -mmSize / 2); ctx.lineTo(0, mmSize / 2);
    ctx.stroke();

    // Map world limits representation scale ratio
    const scale = (mmSize - 10) / WORLD_SIZE;

    // Draw rocks as tiny static grey dots
    ctx.fillStyle = '#57534e';
    s.obstacles.forEach((obs) => {
      const rx = (obs.x - WORLD_SIZE / 2) * scale;
      const ry = (obs.y - WORLD_SIZE / 2) * scale;
      ctx.fillRect(rx - 0.7, ry - 0.7, 1.4, 1.4);
    });

    // Plot snakes as chained dots or lines
    s.snakes.forEach((snake) => {
      if (snake.isDead) return;

      const isPlayer = snake.id === s.playerSnakeId;
      ctx.fillStyle = isPlayer ? '#fbbf24' : SKINS[snake.skin]?.colors.primary || '#ec4899';

      const head = snake.segments[0];
      const mx = (head.x - WORLD_SIZE / 2) * scale;
      const my = (head.y - WORLD_SIZE / 2) * scale;

      // Draw head pointer dot
      ctx.beginPath();
      ctx.arc(mx, my, isPlayer ? 2.5 : 1.5, 0, Math.PI * 2);
      ctx.fill();

      // Plot short tails
      if (isPlayer) {
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.5)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(mx, my);
        // sample every 5th body node
        for (let j = 5; j < snake.segments.length; j += 5) {
          const seg = snake.segments[j];
          const tx = (seg.x - WORLD_SIZE / 2) * scale;
          const ty = (seg.y - WORLD_SIZE / 2) * scale;
          ctx.lineTo(tx, ty);
        }
        ctx.stroke();
      }
    });

    ctx.restore();
  };

  // Player manual speed boost press and hold controllers
  const handleBoostStart = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    stateRef.current.isBoostPressed = true;
  };

  const handleBoostEnd = () => {
    stateRef.current.isBoostPressed = false;
  };

  return (
    <div ref={containerRef} className="absolute inset-0 w-full h-full overflow-hidden select-none">
      <canvas ref={canvasRef} className="absolute inset-0 block w-full h-full cursor-crosshair touch-none" />

      {/* --- HUD PREMIUM OVERLAYS (OPTIMIZED FOR RESPONSIVE PLAY) --- */}

      {/* 1. TOP LEFT QUEST ACHIEVEMENT BADGE (Crowns the circular canvas minimap) */}
      <div className="absolute top-3 left-3 sm:top-4 sm:left-4 bg-stone-950/80 border border-stone-800/80 rounded-xl p-1.5 sm:p-2.5 shadow-xl text-white backdrop-blur-md flex items-center gap-2 select-none pointer-events-none w-40 sm:w-48">
        <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-lg bg-orange-500/10 flex items-center justify-center border border-orange-500/20 text-orange-400 shrink-0">
          <Award className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 animate-pulse" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-center text-[9px] sm:text-[10px] font-black uppercase text-stone-300 tracking-wider">
            <span className="truncate">Quest</span>
            <span className="text-orange-400 font-extrabold ml-1 font-mono">{questCount}/{questGoal}</span>
          </div>
          {/* Progress gauge bar */}
          <div className="w-full h-1.5 sm:h-2 bg-stone-900 rounded-full mt-1 overflow-hidden border border-stone-800/40 leading-none">
            <div
              className="h-full bg-gradient-to-r from-orange-500 to-amber-500 shadow-[0_0_6px_rgba(249,115,22,0.3)] transition-all duration-300"
              style={{ width: `${Math.min(100, (questCount / questGoal) * 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* 2. TOP RIGHT LEADERS STATS BOARD (Sleek, small, compact for both sizes) */}
      <div className="absolute top-3 right-3 sm:top-4 sm:right-4 bg-stone-950/80 border border-stone-800/80 rounded-xl p-2 sm:p-2.5 shadow-xl text-white backdrop-blur-md select-none pointer-events-none w-36 sm:w-44 md:w-48">
        <h3 className="text-[9px] sm:text-[11px] font-black uppercase tracking-widest text-orange-400 flex items-center gap-1.5 border-b border-stone-800/60 pb-1.5 mb-1.5">
          <Trophy className="w-3.5 h-3.5 text-yellow-500 filter drop-shadow-[0_1px_3px_rgba(234,179,8,0.2)]" />
          Leaders
        </h3>
        <div className="space-y-1 text-[9px] sm:text-[10px]">
          {leaderboard.slice(0, 5).map((player, idx) => (
            <div
              key={idx}
              className={`flex items-center justify-between px-1.5 py-0.5 sm:py-1 rounded-md ${
                player.isPlayer
                  ? 'bg-orange-500/15 border border-orange-500/30 text-amber-300 font-black'
                  : 'text-stone-300'
              }`}
            >
              <div className="flex items-center gap-1 min-w-0">
                <span className={`w-3.5 text-center font-extrabold text-[8px] sm:text-[9px] ${idx === 0 ? 'text-yellow-400' : idx === 1 ? 'text-stone-400' : 'text-stone-500'}`}>
                  {idx + 1}
                </span>
                <span className="truncate max-w-[65px] sm:max-w-[100px] font-semibold text-stone-200">
                  {player.name}
                </span>
              </div>
              <span className="font-mono font-bold text-stone-400 ml-1">{player.score}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 3. SCORE STATS BAR (Bottom Left Dashboard) */}
      <div className="absolute bottom-3 left-3 sm:bottom-4 sm:left-4 flex flex-col gap-1.5 p-0.5 pointer-events-none select-none">
        
        {/* Dynamic active powerup counters with compact pills */}
        <div className="flex flex-col gap-1">
          {activeMagnet > 0 && (
            <span className="self-start flex items-center gap-1 px-2.5 py-0.5 bg-blue-600/25 border border-blue-500/40 text-blue-400 text-[8px] sm:text-[9px] font-black uppercase tracking-wider rounded-full shadow-lg backdrop-blur-sm animate-pulse">
              <Zap className="w-2.5 h-2.5 text-blue-400 fill-blue-400" />
              MAGNET: {(activeMagnet / 60).toFixed(0)}s
            </span>
          )}
          {activeShield > 0 && (
            <span className="self-start flex items-center gap-1 px-2.5 py-0.5 bg-emerald-600/25 border border-emerald-500/40 text-emerald-400 text-[8px] sm:text-[9px] font-black uppercase tracking-wider rounded-full shadow-lg backdrop-blur-sm animate-pulse">
              <Shield className="w-2.5 h-2.5 text-emerald-400 fill-emerald-400" />
              SHIELD: {(activeShield / 60).toFixed(0)}s
            </span>
          )}
        </div>

        {/* Scoring Card Dashboard */}
        <div className="bg-stone-950/85 border border-stone-800/80 rounded-xl p-2.5 sm:p-3 pb-1.5 sm:pb-2 shadow-xl text-white backdrop-blur-md flex flex-col gap-1 sm:gap-1.5 min-w-[150px] sm:min-w-[180px]">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-[8px] font-bold text-stone-500 uppercase tracking-wider">Rank</div>
              <div className="text-lg sm:text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-amber-500 leading-none">
                #{playerRank}<span className="text-[10px] text-stone-400 font-bold ml-0.5 font-sans">/{BOT_COUNT + 1}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[8px] font-bold text-stone-500 uppercase tracking-wider">Score</div>
              <div className="text-lg sm:text-xl font-black text-stone-100 font-mono leading-none">
                {playerScore}
              </div>
            </div>
          </div>
          <div className="border-t border-stone-800/40 mt-1 pt-1 flex justify-between items-center text-[8px] text-stone-500 font-bold uppercase tracking-wide">
            <span className="flex items-center gap-0.5"><Compass className="w-2.5 h-2.5" /> LIVE PLAY</span>
            <span>FPS: {fps}</span>
          </div>
        </div>
      </div>

      {/* 4. LIGHTNING BOOST ACTION TRIGGER BUTTON (Bottom Right, tactile feedback layout) */}
      <div className="absolute bottom-4 right-4 select-none flex flex-col items-center">
        <button
          onMouseDown={handleBoostStart}
          onMouseUp={handleBoostEnd}
          onMouseLeave={handleBoostEnd}
          onTouchStart={handleBoostStart}
          onTouchEnd={handleBoostEnd}
          onTouchCancel={handleBoostEnd}
          aria-label="Speed Boost Lightning Bolt Button"
          className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-tr from-yellow-500 via-amber-500 to-orange-500 text-stone-950 flex items-center justify-center border-4 border-stone-900 shadow-[0_4px_16px_rgba(245,158,11,0.4)] active:scale-90 active:shadow-[0_2px_8px_rgba(245,158,11,0.2)] transition transform duration-150 relative cursor-pointer"
        >
          {/* Inner pulsating outline ring */}
          <div className="absolute inset-1 rounded-full border border-white/30 animate-pulse" />
          <Zap className="w-6 h-6 sm:w-7 sm:h-7 fill-stone-950 text-stone-950" />
        </button>
        <span className="text-[7px] sm:text-[8px] font-bold text-amber-500 uppercase tracking-widest mt-1 select-none pointer-events-none drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
          SPEED BOOST
        </span>
      </div>
    </div>
  );
}
